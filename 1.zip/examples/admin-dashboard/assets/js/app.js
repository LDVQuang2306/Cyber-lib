document.addEventListener('DOMContentLoaded', () => {
    const sidebarToggle = document.querySelector('.cp-sidebar-toggle');
    const sidebar = document.querySelector('.cp-sidebar');
    const themeSwitcher = document.querySelector('.cp-theme-switcher');

    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', () => {
            sidebar.classList.toggle('cp-sidebar-open');
        });
    }

    if (themeSwitcher) {
        themeSwitcher.addEventListener('click', () => {
            const currentTheme = localStorage.getItem('cp-theme') || 'cyberpunk';
            const newTheme = currentTheme === 'cyberpunk' ? 'dark' : 'cyberpunk';
            document.documentElement.classList.remove(`cp-theme-${currentTheme}`);
            document.documentElement.classList.add(`cp-theme-${newTheme}`);
            localStorage.setItem('cp-theme', newTheme);
        });
    }

    // Initialize components
    Cyberpunk.Accordion.init();
    Cyberpunk.Alert.init();
    Cyberpunk.Button.init();
    Cyberpunk.Carousel.init();
    Cyberpunk.Dropdown.init();
    Cyberpunk.Modal.init();
    Cyberpunk.Tooltip.init();
    Cyberpunk.Toast.init();
    Cyberpunk.Popover.init();

    // Initialize components specific to the admin dashboard
    const userDropdown = new Cyberpunk.Dropdown(document.getElementById('userDropdown'));

    // Initialize any other components here
});