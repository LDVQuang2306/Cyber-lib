/* README */ 
## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

Copyright (c) 2025 [LDVQuang](https://github.com/LDVQuang) (Lê Đăng Việt Quang).