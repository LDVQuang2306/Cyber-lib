/* JS utils files */ 
export function getRoute() {
    return window.location.pathname;
  }
  
  export function navigateTo(path) {
    window.history.pushState({}, '', path);
    window.dispatchEvent(new Event('popstate'));
  }