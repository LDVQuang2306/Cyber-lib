/* JS utils files */ 
export function animate(element, animationClass, callback) {
    element.classList.add('cp-animated', animationClass);
  
    function handleAnimationEnd() {
      element.classList.remove('cp-animated', animationClass);
      element.removeEventListener('animationend', handleAnimationEnd);
  
      if (typeof callback === 'function') {
        callback();
      }
    }
  
    element.addEventListener('animationend', handleAnimationEnd);
  }