/* JS utils files */ 
export function setLocalStorageItem(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }
  
  export function getLocalStorageItem(key) {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : null;
  }
  
  export function removeLocalStorageItem(key) {
    localStorage.removeItem(key);
  }
  
  export function setSessionStorageItem(key, value) {
    sessionStorage.setItem(key, JSON.stringify(value));
  }
  
  export function getSessionStorageItem(key) {
    const value = sessionStorage.getItem(key);
    return value ? JSON.parse(value) : null;
  }
  
  export function removeSessionStorageItem(key) {
    sessionStorage.removeItem(key);
  }