/* JS utils files */ 
export function isEnterKey(event) {
    return event.key === 'Enter';
  }
  
  export function isEscapeKey(event) {
    return event.key === 'Escape';
  }
  
  export function isSpaceKey(event) {
    return event.code === 'Space';
  }
  
  export function isTabKey(event) {
    return event.key === 'Tab';
  }
  
  export function isArrowUpKey(event) {
    return event.key === 'ArrowUp';
  }
  
  export function isArrowDownKey(event) {
    return event.key === 'ArrowDown';
  }
  
  export function isArrowLeftKey(event) {
    return event.key === 'ArrowLeft';
  }
  
  export function isArrowRightKey(event) {
    return event.key === 'ArrowRight';
  }