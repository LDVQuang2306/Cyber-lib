/* JS utils files */ 
export function capitalize(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }
  
  export function camelCaseToDash(string) {
    return string.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
  }
  
  export function dashToCamelCase(string) {
    return string.replace(/-([a-z])/g, (g) => g[1].toUpperCase());
  }
  
  export function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }