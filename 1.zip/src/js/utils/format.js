/* JS utils files */ 
export function formatNumber(number, decimals = 2) {
    return number.toFixed(decimals);
  }
  
  export function formatCurrency(amount, currency = 'USD') {
    return new Intl.NumberFormat('en-US', {style: 'currency',
        currency: currency,
      }).format(amount);
    }
    
    export function formatPercentage(number) {
      return new Intl.NumberFormat('en-US', {
        style: 'percent',
        minimumFractionDigits: 2,
      }).format(number);
    }