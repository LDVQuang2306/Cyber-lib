/* JS utils files */ 
export function isEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }
  
  export function isRequired(value) {
    return value !== null && value !== undefined && value.trim() !== '';
  }
  
  export function isNumber(value) {
    return !isNaN(parseFloat(value)) && isFinite(value);
  }
  
  export function isInteger(value) {
    return Number.isInteger(Number(value));
  }
  
  export function isMinLength(value, min) {
    return value.length >= min;
  }
  
  export function isMaxLength(value, max) {
    return value.length <= max;
  }
  
  export function isBetween(value, min, max) {
    return value >= min && value <= max;
  }