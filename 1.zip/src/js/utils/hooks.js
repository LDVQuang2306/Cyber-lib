/* JS utils files */ 
const _hooks = {};

export function addHook(name, callback) {
  if (!_hooks[name]) {
    _hooks[name] = [];
  }
  _hooks[name].push(callback);
}

export function removeHook(name, callback) {
  if (_hooks[name]) {
    _hooks[name] = _hooks[name].filter(cb => cb !== callback);
  }
}

export function triggerHook(name, ...args) {
  if (_hooks[name]) {
    _hooks[name].forEach(callback => callback(...args));
  }
}