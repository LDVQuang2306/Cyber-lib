/* JS utils files */ 
export function getElement(selector) {
    return document.querySelector(selector);
  }
  
  export function getElements(selector) {
    return document.querySelectorAll(selector);
  }
  
  export function addClass(element, className) {
    element.classList.add(className);
  }
  
  export function removeClass(element, className) {
    element.classList.remove(className);
  }
  
  export function toggleClass(element, className) {
    element.classList.toggle(className);
  }
  
  export function hasClass(element, className) {
    return element.classList.contains(className);
  }
  
  export function getFocusableElements(container) {
    return [...container.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')];
  }
  
  export function autoInitComponent(componentName, options, ComponentClass) {
    const elements = document.querySelectorAll(`[data-cp-${componentName}]`);
    elements.forEach(element => {
      const instanceOptions = element.dataset.cpOptions ? JSON.parse(element.dataset.cpOptions) : {};
      new ComponentClass(element, { ...options, ...instanceOptions });
    });
  }