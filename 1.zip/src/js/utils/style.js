/* JS utils files */ 
export function getStyle(element, property) {
    return window.getComputedStyle(element)[property];
  }
  
  export function setStyle(element, property, value) {
    element.style[property] = value;
  }
  
  export function addStyles(element, styles) {
    for (const property in styles) {
      setStyle(element, property, styles[property]);
    }
  }