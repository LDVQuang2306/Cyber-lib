/* JS utils files */ 
export function on(element, event, handler) {
    element.addEventListener(event, handler);
  }
  
  export function off(element, event, handler) {
    element.removeEventListener(event, handler);
  }
  
  export function once(element, event, handler) {
    element.addEventListener(event, handler, { once: true });
  }
  
  export function trigger(element, event) {
    element.dispatchEvent(new Event(event));
  }