/* JS utils files */ 
export function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }
  
  export function random(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
  
  export function round(value, decimals = 0) {
    const factor = 10 ** decimals;
    return Math.round(value * factor) / factor;
  }