/* JS plugins files */ 
import { Plugin } from '../core/Plugin';

export class Theme extends Plugin {
  constructor() {
    super();
    this.applyTheme(this.getCurrentTheme());
    this.initThemeSwitcher();
  }

  static get pluginName() {
    return 'theme';
  }

  getCurrentTheme() {
    return localStorage.getItem('cp-theme') || 'cyberpunk';
  }

  applyTheme(theme) {
    document.body.classList.remove('cp-theme-light', 'cp-theme-dark', 'cp-theme-custom');
    document.body.classList.add(`cp-theme-${theme}`);
    localStorage.setItem('cp-theme', theme);
  }

  initThemeSwitcher() {
    const themeSwitcher = document.querySelector('[data-cp-theme-switcher]');
    if (themeSwitcher) {
      themeSwitcher.addEventListener('change', (event) => {
        this.applyTheme(event.target.value);
      });
    }
  }
}