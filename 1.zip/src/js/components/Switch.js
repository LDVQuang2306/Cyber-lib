/* JS components files */ 
import { Component } from '../core/Component';

export class Switch extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.input = this.element.querySelector('input');
    this.init();
  }

  init() {
    this.element.addEventListener('click', () => {
      this.input.checked = !this.input.checked;
      this.input.dispatchEvent(new Event('change'));
    });
  }

  static get componentName() {
    return 'switch';
  }

  static get defaultOptions() {
    return {};
  }
}