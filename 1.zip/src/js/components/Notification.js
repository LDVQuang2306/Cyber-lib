/* JS components files */ 
import { Component } from '../core/Component';

export class Notification extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.closeButton = this.element.querySelector('.cp-close');
    this.init();
    this.show();
  }

  init() {
    if (this.closeButton) {
      this.closeButton.addEventListener('click', () => this.close());
    }
    
    setTimeout(() => {
      this.close();
    }, 3000);
  }

  show() {
    this.element.classList.add('cp-show');
  }

  close() {
    this.element.remove();
  }

  static get componentName() {
    return 'notification';
  }

  static get defaultOptions() {
    return {};
  }
}