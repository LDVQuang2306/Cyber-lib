/* JS components files */ 
import { Component } from '../core/Component';
import { createPopper } from '@popperjs/core';

export class Tooltip extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.popperInstance = null;
    this.tooltip = document.createElement('div');
    this.tooltip.setAttribute('role', 'tooltip');
    this.tooltip.classList.add('cp-tooltip');
    this.tooltip.innerHTML = `<div class="cp-tooltip-inner"></div><div class="cp-arrow" data-popper-arrow></div>`;

    this.init();
  }

  init() {
    document.body.appendChild(this.tooltip);

    this.element.addEventListener('mouseenter', () => this.show());
    this.element.addEventListener('mouseleave', () => this.hide());
  }

  createPopperInstance() {
    this.popperInstance = createPopper(this.element, this.tooltip, {
      placement: this.options.placement,
      modifiers: [
        {
          name: 'offset',
          options: {
            offset: [0, 8],
          },
        },
      ],
    });
  }

  show() {
    this.tooltip.querySelector('.cp-tooltip-inner').textContent = this.options.title;
    this.tooltip.classList.add('cp-show');
    this.createPopperInstance();
    this.popperInstance.update();
  }

  hide() {
    this.tooltip.classList.remove('cp-show');

    if (this.popperInstance) {
      this.popperInstance.destroy();
      this.popperInstance = null;
    }
  }

  static get componentName() {
    return 'tooltip';
  }

  static get defaultOptions() {
    return {
      placement: 'top',
      title: '',
      trigger: 'hover focus',
    };
  }
}