/* JS components files */ 
import { Component } from '../core/Component';

export class Modal extends Component {
  constructor(element, options = {}) {
    super(element, options);

    this.dialog = this.element.querySelector('.cp-modal-dialog');
    this.closeButton = this.element.querySelector('.cp-close');
    this.init();
  }

  init() {
    if (this.options.backdrop) {
      this.backdrop = document.createElement('div');
      this.backdrop.classList.add('cp-modal-backdrop', 'cp-fade');
      document.body.appendChild(this.backdrop);
      this.backdrop.addEventListener('click', () => this.close());
    }
    this.element.addEventListener('click', (e) => {
      if (e.target == this.element) {
        this.close();
      }
    })
    if (this.closeButton) {
      this.closeButton.addEventListener('click', () => this.close());
    }

    this.element.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && this.options.keyboard) {
        this.close();
      }
    });
  }

  open() {
    this.element.style.display = 'block';
    document.body.style.overflow = 'hidden'; // Prevent scrolling of the background
    document.body.classList.add('cp-modal-open');

    setTimeout(() => {
      this.element.classList.add('cp-show');
      if (this.backdrop) {
        this.backdrop.classList.add('cp-show');
      }
    }, 50);
  }

  close() {
    this.element.classList.remove('cp-show');
    if (this.backdrop) {
      this.backdrop.classList.remove('cp-show');
    }
    document.body.style.overflow = ''; // Restore scrolling
    document.body.classList.remove('cp-modal-open');
    this.element.addEventListener('transitionend', () => {
      this.element.style.display = 'none';
    }, { once: true });
  }

  static get componentName() {
    return 'modal';
  }

  static get defaultOptions() {
    return {
      backdrop: true,
      keyboard: true,
      focus: true
    };
  }
}