/* JS components files */ 
import { Component } from '../core/Component';

export class Form extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'form';
  }

  static get defaultOptions() {
    return {};
  }
}