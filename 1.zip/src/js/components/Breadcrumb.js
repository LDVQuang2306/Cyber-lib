/* JS components files */ 
import { Component } from '../core/Component';

export class Breadcrumb extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'breadcrumb';
  }

  static get defaultOptions() {
    return {};
  }
}