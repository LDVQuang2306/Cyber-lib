/* JS components files */ 
import { Component } from '../core/Component';

export class Accordion extends Component {
  constructor(element, options = {}) {
    super(element, options);

    this.items = this.element.querySelectorAll('.cp-accordion-item');
    this.init();
  }

  init() {
    this.items.forEach(item => {
      const header =item.querySelector('.cp-accordion-header');
      header.addEventListener('click', () => this.toggleItem(item));
    });
  }

  toggleItem(item) {
    const isExpanded = item.classList.contains('cp-active');

    this.items.forEach(otherItem => {
      if (otherItem !== item) {
        otherItem.classList.remove('cp-active');
      }
    });

    if (isExpanded) {
      item.classList.remove('cp-active');
    } else {
      item.classList.add('cp-active');
    }
  }

  static get componentName() {
    return 'accordion';
  }

  static get defaultOptions() {
    return {};
  }
}