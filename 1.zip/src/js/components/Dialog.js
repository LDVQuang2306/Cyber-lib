/* JS components files */ 
import { Component } from '../core/Component';
import { getFocusableElements } from '../utils/dom';

export class Dialog extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.dialog = this.element.querySelector('.cp-dialog-content');
    this.closeButton = this.element.querySelector('.cp-close');
    this.init();
  }

  init() {
    this.element.addEventListener('click', (event) => {
      if (event.target === this.element) {
        this.close();
      }
    });

    if (this.closeButton) {
      this.closeButton.addEventListener('click', () => this.close());
    }

    this.element.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        this.close();
      }
    });

    this.dialog.addEventListener('keydown', (event) => {
      if (event.key === 'Tab') {
        const focusableElements = getFocusableElements(this.dialog);
        const firstFocusable = focusableElements[0];
        const lastFocusable = focusableElements[focusableElements.length - 1];

        if (event.shiftKey) {
          if (document.activeElement === firstFocusable) {
            event.preventDefault();
            lastFocusable.focus();
          }
        } else {
          if (document.activeElement === lastFocusable) {
            event.preventDefault();
            firstFocusable.focus();
          }
        }
      }
    });
  }

  open() {
    this.element.style.display = 'flex';
    document.body.style.overflow = 'hidden'; // Prevent scrolling of the background

    setTimeout(() => {
      this.element.classList.add('cp-show');
      const focusableElements = getFocusableElements(this.dialog);
      if (focusableElements.length > 0) {
        focusableElements[0].focus();
      }
    }, 50);
  }

  close() {
    this.element.classList.remove('cp-show');
    document.body.style.overflow = ''; // Restore scrolling
    this.element.addEventListener('transitionend', () => {
      this.element.style.display = 'none';
    }, { once: true });
  }

  static get componentName() {
    return 'dialog';
  }

  static get defaultOptions() {
    return {
      backdrop: true,
      keyboard: true,
      focus: true,
    };
  }
}