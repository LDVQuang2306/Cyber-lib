/* JS components files */ 
import { Component } from '../core/Component';

export class Pagination extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'pagination';
  }

  static get defaultOptions() {
    return {};
  }
}