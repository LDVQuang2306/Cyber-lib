/* JS components files */ 
import { Component } from '../core/Component';

export class Avatar extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'avatar';
  }

  static get defaultOptions() {
    return {};
  }
}