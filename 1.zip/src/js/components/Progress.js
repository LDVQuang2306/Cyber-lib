/* JS components files */ 
import { Component } from '../core/Component';

export class Progress extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'progress';
  }

  static get defaultOptions() {
    return {};
  }
}