/* JS components files */ 
import { Component } from '../core/Component';

export class Toast extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.init();
  }

  init() {
    setTimeout(() => this.show(), this.options.delay);
  }

  show() {
    this.element.classList.add('cp-show');
    this.element.addEventListener('transitionend', () => {
        setTimeout(() => {
          this.hide();
        }, this.options.autohideDelay);
      }, { once: true });
  }

  hide() {
    this.element.classList.remove('cp-show');
    this.element.addEventListener('transitionend', () => {
        this.element.remove();
      }, { once: true });
  }

  static get componentName() {
    return 'toast';
  }

  static get defaultOptions() {
    return {
      animation: true,
      autohide: true,
      delay: 500, // Delay before showing
      autohideDelay: 5000,
    };
  }
}