import { Component } from '../core/Component';

export class Dropdown extends Component {
  constructor(element, options = {}) {
    super(element, options);

    this.toggle = this.element.querySelector('.cp-dropdown-toggle');
    this.menu = this.element.querySelector('.cp-dropdown-menu');
    this.isOpen = false;
    this.init();
  }

  init() {
    this.toggle.addEventListener('click', (event) => {
      event.preventDefault();
      this.toggleDropdown();
    });

    document.addEventListener('click', (event) => {
      if (!this.element.contains(event.target)) {
        this.close();
      }
    });
    this.element.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        this.close();
      }
    });
  }

  toggleDropdown() {
    this.isOpen = !this.isOpen;
    this.menu.classList.toggle('cp-show', this.isOpen);
  }

  open() {
    this.isOpen = true;
    this.menu.classList.add('cp-show');
  }

  close() {
    this.isOpen = false;
    this.menu.classList.remove('cp-show');
  }

  static get componentName() {
    return 'dropdown';
  }

  static get defaultOptions() {
    return {};
  }
}