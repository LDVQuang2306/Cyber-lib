/* JS components files */ 
import { Component } from '../core/Component';

export class Offcanvas extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.backdrop = null;

    this.init();
  }

  init() {
    if (this.options.backdrop) {
      this.backdrop = document.createElement('div');
      this.backdrop.classList.add('cp-offcanvas-backdrop');
      document.body.appendChild(this.backdrop);

      this.backdrop.addEventListener('click', () => this.close());
    }

    this.element.addEventListener('transitionend', () => {
      if (!this.element.classList.contains('cp-show')) {
        this.element.style.visibility = 'hidden';
      }
    });
  }

  open() {
    this.element.style.visibility = 'visible';
    this.element.classList.add('cp-show');

    if (this.backdrop) {
      this.backdrop.classList.add('cp-show');
    }
  }

  close() {
    this.element.classList.remove('cp-show');

    if (this.backdrop) {
      this.backdrop.classList.remove('cp-show');
    }
  }

  static get componentName() {
    return 'offcanvas';
  }

  static get defaultOptions() {
    return {
      backdrop: true,
      keyboard: true,
      scroll: false,
    };
  }
}