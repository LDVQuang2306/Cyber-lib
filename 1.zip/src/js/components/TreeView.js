/* JS components files */ 
import { Component } from '../core/Component';

export class TreeView extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.init();
  }

  init() {
    const toggles = this.element.querySelectorAll('.cp-tree-node-content');
    toggles.forEach(toggle => {
      toggle.addEventListener('click', () => {
        const node = toggle.closest('.cp-tree-node');
        if (node.classList.contains('cp-has-children')) {
          node.classList.toggle('cp-expanded');
          const children = node.querySelector('.cp-tree-node-children');
          if (children) {
            children.classList.toggle('cp-open');
          }
        }
      });
    });
  }

  static get componentName() {
    return 'treeView';
  }

  static get defaultOptions() {
    return {};
  }
}