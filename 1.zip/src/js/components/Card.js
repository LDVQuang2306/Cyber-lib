/* JS components files */ 
import { Component } from '../core/Component';

export class Card extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'card';
  }

  static get defaultOptions() {
    return {};
  }
}