/* JS components files */ 
import { Component } from '../core/Component';

export class MegaMenu extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.trigger = this.element.querySelector('.cp-megamenu-trigger');
    this.content = this.element.querySelector('.cp-megamenu-content');
    this.init();
  }

  init() {
    this.trigger.addEventListener('mouseenter', () => this.open());
    this.element.addEventListener('mouseleave', () => this.close());
  }

  open() {
    this.content.style.display = 'block';
  }

  close() {
    this.content.style.display = 'none';
  }

  static get componentName() {
    return 'megaMenu';
  }

  static get defaultOptions() {
    return {};
  }
}