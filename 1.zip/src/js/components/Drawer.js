/* JS components files */ 
import { Component } from '../core/Component';

export class Drawer extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.isOpen = false;
    this.backdrop = null;

    this.init();
  }

  init() {
    if (this.options.backdrop) {
      this.backdrop = document.createElement('div');
      this.backdrop.classList.add('cp-drawer-backdrop');
      document.body.appendChild(this.backdrop);

      this.backdrop.addEventListener('click', () => this.close());
    }

    this.element.addEventListener('transitionend', () => {
      if (!this.isOpen) {
        this.element.style.display = 'none';
        if (this.backdrop) {
          this.backdrop.style.display = 'none';
        }
      }
    });
  }

  open() {
    this.isOpen = true;
    this.element.style.display = 'flex';
    if (this.backdrop) {
      this.backdrop.style.display = 'block';
    }
    setTimeout(() => {
      this.element.classList.add('cp-open');
      if (this.backdrop) {
        this.backdrop.classList.add('cp-open');
      }
    }, 50);
  }

  close() {
    this.isOpen = false;
    this.element.classList.remove('cp-open');
    if (this.backdrop) {
      this.backdrop.classList.remove('cp-open');
    }
  }

  toggle() {
    if (this.isOpen) {
      this.close();
    } else {
      this.open();
    }
  }

  static get componentName() {
    return 'drawer';
  }

  static get defaultOptions() {
    return {
      backdrop: true,
      position: 'left', // 'left', 'right', 'top', 'bottom'
    };
  }
}