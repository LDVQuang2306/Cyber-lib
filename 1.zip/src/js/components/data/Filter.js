/* JS components files */ 
import { Component } from '../../core/Component';

export class Filter extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'filter';
  }

  static get defaultOptions() {
    return {};
  }
}