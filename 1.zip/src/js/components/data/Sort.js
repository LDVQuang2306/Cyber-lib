/* JS components files */ 
import { Component } from '../../core/Component';

export class Sort extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'sort';
  }

  static get defaultOptions() {
    return {};
  }
}