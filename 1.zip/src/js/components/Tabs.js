/* JS components files */ 
import { Component } from '../core/Component';

export class Tabs extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.navLinks = this.element.querySelectorAll('.cp-nav-link');
    this.tabPanes = this.element.querySelectorAll('.cp-tab-pane');

    this.init();
  }

  init() {
    this.navLinks.forEach(link => {
      link.addEventListener('click', (event) => {
        event.preventDefault();
        const targetId = link.getAttribute('href');
        const targetPane = document.querySelector(targetId);
        this.showTab(targetPane);
      });
    });

    // Show the first tab by default
    if (this.tabPanes.length > 0) {
      this.showTab(this.tabPanes[0]);
    }
  }

  showTab(tabPane) {
    // Deactivate all tabs and tab panes
    this.navLinks.forEach(link => link.classList.remove('cp-active'));
    this.tabPanes.forEach(pane => pane.classList.remove('cp-active'));

    // Activate the clicked tab and its corresponding tab pane
    const targetLinkId = `#${tabPane.id}`;
    const targetLink = this.element.querySelector(`.cp-nav-link[href="${targetLinkId}"]`);
    targetLink.classList.add('cp-active');
    tabPane.classList.add('cp-active');
  }

  static get componentName() {
    return 'tabs';
  }

  static get defaultOptions() {
    return {};
  }
}