/* JS components files */ 
import { Component } from '../core/Component';

export class Steps extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.steps = this.element.querySelectorAll('.cp-step');
    this.init();
  }

  init() {
    this.steps.forEach((step, index) => {
      step.addEventListener('click', () => this.goToStep(index));
    });
  }

  goToStep(index) {
    this.steps.forEach((step, i) => {
      step.classList.remove('cp-active', 'cp-completed');
      if (i < index) {
        step.classList.add('cp-completed');
      } else if (i === index) {
        step.classList.add('cp-active');
      }
    });
  }

  static get componentName() {
    return 'steps';
  }

  static get defaultOptions() {
    return {
      initialStep: 0,
    };
  }
}