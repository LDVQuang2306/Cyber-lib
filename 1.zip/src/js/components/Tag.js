/* JS components files */ 
import { Component } from '../core/Component';

export class Tag extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'tag';
  }

  static get defaultOptions() {
    return {};
  }
}