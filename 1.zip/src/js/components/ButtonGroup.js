/* JS components files */ 
import { Component } from '../core/Component';

export class ButtonGroup extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'buttonGroup';
  }

  static get defaultOptions() {
    return {};
  }
}