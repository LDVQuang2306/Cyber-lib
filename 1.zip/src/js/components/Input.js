/* JS components files */ 
import { Component } from '../core/Component';

export class Input extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'input';
  }

  static get defaultOptions() {
    return {};
  }
}