/* JS components files */ 
import { Component } from '../core/Component';

export class Carousel extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.currentIndex = 0;
    this.items = this.element.querySelectorAll('.cp-carousel-item');
    this.indicators = this.element.querySelectorAll('.cp-carousel-indicators li');
    this.prevButton = this.element.querySelector('.cp-carousel-control-prev');
    this.nextButton = this.element.querySelector('.cp-carousel-control-next');

    this.init();
  }

  init() {
    this.showItem(this.currentIndex);

    if (this.prevButton) {
      this.prevButton.addEventListener('click', () => this.prev());
    }

    if (this.nextButton) {
      this.nextButton.addEventListener('click', () => this.next());
    }

    if (this.indicators.length) {
      this.indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', () => this.goTo(index));
      });
    }
    
    setInterval(() => {
      this.next();
    }, 3000);
  }

  showItem(index) {
    this.items.forEach(item => item.classList.remove('cp-active'));
    this.items[index].classList.add('cp-active');

    if (this.indicators.length) {
      this.indicators.forEach(indicator => indicator.classList.remove('cp-active'));
      this.indicators[index].classList.add('cp-active');
    }
  }

  prev() {
    this.currentIndex = (this.currentIndex - 1 + this.items.length) % this.items.length;
    this.showItem(this.currentIndex);
  }

  next() {
    this.currentIndex = (this.currentIndex + 1) % this.items.length;
    this.showItem(this.currentIndex);
  }

  goTo(index) {
    this.currentIndex = index;
    this.showItem(this.currentIndex);
  }

  static get componentName() {
    return 'carousel';
  }

  static get defaultOptions() {
    return {
      interval: 5000,
      wrap: true,
      keyboard: true,
    };
  }
}