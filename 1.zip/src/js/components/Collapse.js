/* JS components files */ 
import { Component } from '../core/Component';

export class Collapse extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.init();
  }

  init() {
    this.element.addEventListener('click', () => this.toggle());
  }

  toggle() {
    const targetId = this.element.dataset.target;
    const target = document.querySelector(targetId);

    if (target) {
      if (target.classList.contains('cp-show')) {
        this.hide(target);
      } else {
        this.show(target);
      }
    }
  }

  show(target) {
    target.style.display = 'block';
    setTimeout(() => {
        target.classList.add('cp-show');
    }, 50);
  }

  hide(target) {
    target.classList.remove('cp-show');
    target.addEventListener('transitionend', () => {
      target.style.display = 'none';
    }, { once: true });
  }

  static get componentName() {
    return 'collapse';
  }

  static get defaultOptions() {
    return {};
  }
}