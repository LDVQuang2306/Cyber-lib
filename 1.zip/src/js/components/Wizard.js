/* JS components files */ 
import { Component } from '../core/Component';

export class Wizard extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.steps = this.element.querySelectorAll('.cp-wizard-step');
    this.content = this.element.querySelectorAll('.cp-wizard-pane');
    this.prevButton = this.element.querySelector('.cp-wizard-prev');
    this.nextButton = this.element.querySelector('.cp-wizard-next');
    this.currentStep = 0;

    this.init();
  }

  init() {
    this.showStep(this.currentStep);

    if (this.prevButton) {
      this.prevButton.addEventListener('click', () => this.prevStep());
    }

    if (this.nextButton) {
      this.nextButton.addEventListener('click', () => this.nextStep());
    }
  }

  showStep(index) {
    this.steps.forEach((step, i) => {
      step.classList.remove('cp-active', 'cp-completed');
      if (i < index) {
        step.classList.add('cp-completed');
      } else if (i === index) {
        step.classList.add('cp-active');
      }
    });

    this.content.forEach((pane, i) => {
      pane.style.display = i === index ? 'block' : 'none';
    });

    if (this.prevButton) {
      this.prevButton.disabled = index === 0;
    }

    if (this.nextButton) {
      this.nextButton.disabled = index === this.steps.length - 1;
    }
  }

  prevStep() {
    if (this.currentStep > 0) {
      this.currentStep--;
      this.showStep(this.currentStep);
    }
  }

  nextStep() {
    if (this.currentStep < this.steps.length - 1) {
      this.currentStep++;
      this.showStep(this.currentStep);
    }
  }

  static get componentName() {
    return 'wizard';
  }

  static get defaultOptions() {
    return {};
  }
}