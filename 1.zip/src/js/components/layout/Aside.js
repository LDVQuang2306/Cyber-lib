/* JS components files */ 
import { Component } from '../../core/Component';

export class Aside extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'aside';
  }

  static get defaultOptions() {
    return {};
  }
}