/* JS components files */ 
import { Component } from '../../core/Component';

export class Section extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'section';
  }

  static get defaultOptions() {
    return {};
  }
}