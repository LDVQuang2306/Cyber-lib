/* JS components files */ 
import { Component } from '../../core/Component';

export class Main extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'main';
  }

  static get defaultOptions() {
    return {};
  }
}