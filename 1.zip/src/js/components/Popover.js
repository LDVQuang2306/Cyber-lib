/* JS components files */ 
import { Component } from '../core/Component';
import { createPopper } from '@popperjs/core';

export class Popover extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.popperInstance = null;
    this.tooltip = document.createElement('div');
    this.tooltip.setAttribute('role', 'tooltip');
    this.tooltip.classList.add('cp-popover');
    this.tooltip.innerHTML = `<div class="cp-arrow" data-popper-arrow></div>
                                <h3 class="cp-popover-header"></h3>
                                <div class="cp-popover-body"></div>`;

    this.init();
  }

  init() {
    document.body.appendChild(this.tooltip);

    this.element.addEventListener('click', () => {
      if (this.popperInstance) {
        this.hide();
      } else {
        this.show();
      }
    });
  }

  createPopperInstance() {
    this.popperInstance = createPopper(this.element, this.tooltip, {
      placement: this.options.placement,
      modifiers: [
        {
          name: 'offset',
          options: {
            offset: [0, 8],
          },
        },
      ],
    });
  }

  show() {
    this.tooltip.querySelector('.cp-popover-header').textContent = this.options.title;
    this.tooltip.querySelector('.cp-popover-body').textContent = this.options.content;
    this.tooltip.classList.add('cp-show');
    this.createPopperInstance();
    this.popperInstance.update();
  }

  hide() {
    this.tooltip.classList.remove('cp-show');
    this.popperInstance.destroy();
    this.popperInstance = null;
  }

  static get componentName() {
    return 'popover';
  }

  static get defaultOptions() {
    return {
      placement: 'top',
      title: '',
      content: '',
      trigger: 'click',
    };
  }
}