/* JS components files */ 
import { Component } from '../../core/Component';

export class Validation extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'validation';
  }

  static get defaultOptions() {
    return {};
  }
}