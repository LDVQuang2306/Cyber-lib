/* JS components files */ 
import { Component } from '../../core/Component';

export class Checkbox extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'checkbox';
  }

  static get defaultOptions() {
    return {};
  }
}