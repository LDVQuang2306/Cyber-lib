import { Component } from '../../core/Component';

export class Radio extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'radio';
  }

  static get defaultOptions() {
    return {};
  }
}