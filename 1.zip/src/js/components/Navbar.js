/* JS components files */ 
import { Component } from '../core/Component';

export class Navbar extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'navbar';
  }

  static get defaultOptions() {
    return {};
  }
}