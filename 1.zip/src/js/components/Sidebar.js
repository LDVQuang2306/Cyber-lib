/* JS components files */ 
import { Component } from '../core/Component';

export class Sidebar extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'sidebar';
  }

  static get defaultOptions() {
    return {};
  }
}