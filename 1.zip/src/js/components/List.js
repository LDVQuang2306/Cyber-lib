/* JS components files */ 
import { Component } from '../core/Component';

export class List extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'list';
  }

  static get defaultOptions() {
    return {};
  }
}