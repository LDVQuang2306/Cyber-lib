/* JS components files */ 
import { Component } from '../core/Component';

export class Media extends Component {
  constructor(element, options = {}) {
    super(element, options);
  }

  static get componentName() {
    return 'media';
  }

  static get defaultOptions() {
    return {};
  }
}