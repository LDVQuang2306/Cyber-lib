/* JS components files */ 
import { Component } from '../core/Component';

export class Rating extends Component {
  constructor(element, options = {}) {
    super(element, options);

    this.stars = Array.from({ length: 5 }, (_, i) => i + 1);
    this.init();
  }

  init() {
    this.stars.forEach(star => {
      const label = document.createElement('label');
      const input = document.createElement('input');
      input.type = 'radio';
      input.name = `rating-${this.element.id}`;
      input.value = star;
      label.appendChild(input);
      label.addEventListener('click', () => this.setValue(star));
      label.addEventListener('mouseover', () => this.highlightStars(star));
      label.addEventListener('mouseleave', () => this.resetStars());
      this.element.appendChild(label);
    });
  }

  setValue(value) {
    this.options.value = value;
    this.element.querySelectorAll('label').forEach((label, index) => {
      label.classList.toggle('cp-checked', index < value);
    });
  }

  highlightStars(value) {
    this.element.querySelectorAll('label').forEach((label, index) => {
      label.classList.toggle('cp-hovered', index < value);
    });
  }

  resetStars() {
    this.element.querySelectorAll('label').forEach((label, index) => {
      label.classList.remove('cp-hovered');
      label.classList.toggle('cp-checked', index < this.options.value);
    });
  }

  static get componentName() {
    return 'rating';
  }

  static get defaultOptions() {
    return {
      value: 0,
    };
  }
}