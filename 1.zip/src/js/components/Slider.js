/* JS components files */ 
import { Component } from '../core/Component';

export class Slider extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.init();
  }

  init() {
    this.element.addEventListener('input', () => {
      this.options.value = this.element.value;
      this.element.dispatchEvent(new Event('change'));
    });
  }

  static get componentName() {
    return 'slider';
  }

  static get defaultOptions() {
    return {
      min: 0,
      max: 100,
      value: 50,
      step: 1,
    };
  }
}