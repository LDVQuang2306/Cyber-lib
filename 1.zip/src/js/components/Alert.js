/* JS components files */ 
import { Component } from '../core/Component';

export class Alert extends Component {
  constructor(element, options = {}) {
    super(element, options);
    this.closeButton = this.element.querySelector('.cp-close');
    this.init();
  }

  init() {
    if (this.closeButton) {
      this.closeButton.addEventListener('click', () => this.close());
    }
  }

  close() {
    this.element.remove();
  }

  static get componentName() {
    return 'alert';
  }

  static get defaultOptions() {
    return {};
  }
}