/* JS services files */ 
export class CacheService {
    constructor(storage = localStorage) {
      this.storage = storage;
    }
  
    get(key) {
      const data = this.storage.getItem(key);
      return data ? JSON.parse(data) : null;
    }
  
    set(key, value, ttl = null) {
      const item = {
        value,
        expiry: ttl ? Date.now() + ttl : null,
      };
      this.storage.setItem(key, JSON.stringify(item));
    }
  
    remove(key) {
      this.storage.removeItem(key);
    }
  
    clear() {
      this.storage.clear();
    }
  
    isExpired(key) {
      const item = this.get(key);
      return item && item.expiry && Date.now() > item.expiry;
    }
  }