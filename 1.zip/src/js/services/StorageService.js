/* JS services files */ 
export class StorageService {
    constructor(storage = localStorage) {
      this.storage = storage;
    }
  
    get(key) {
      const data = this.storage.getItem(key);
      return data ? JSON.parse(data) : null;
    }
  
    set(key, value) {
      this.storage.setItem(key, JSON.stringify(value));
    }
  
    remove(key) {
      this.storage.removeItem(key);
    }
  
    clear() {
      this.storage.clear();
    }
  }