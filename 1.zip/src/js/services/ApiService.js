/* JS services files */ 
export class ApiService {
    constructor() {
      this.baseUrl = ''; // Set your base API URL here
    }
  
    async get(endpoint) {
      const response = await fetch(`${this.baseUrl}${endpoint}`);
      return await response.json();
    }
  
    async post(endpoint, data) {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      return await response.json();
    }
  
    // Add more methods like put, delete, etc. as needed
  }