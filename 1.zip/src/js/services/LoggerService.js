/* JS services files */ 
export class LoggerService {
    constructor(level = 'info') {
      this.level = level;
    }
  
    log(level, message) {
      if (this.shouldLog(level)) {
        console[level](message);
      }
    }
  
    debug(message) {
      this.log('debug', message);
    }
  
    info(message) {
      this.log('info', message);
    }
  
    warn(message) {
      this.log('warn', message);
    }
  
    error(message) {
      this.log('error', message);
    }
  
    shouldLog(level) {
      const levels = ['debug', 'info', 'warn', 'error'];
      return levels.indexOf(level) >= levels.indexOf(this.level);
    }
  }