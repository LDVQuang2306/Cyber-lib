/* Main JS file */ 
// Core
import { autoInitComponent } from './utils/dom';
import { Accordion } from './components/Accordion';
import { Alert } from './components/Alert';
import { Avatar } from './components/Avatar';
import { Badge } from './components/Badge';
import { Breadcrumb } from './components/Breadcrumb';
import { Button } from './components/Button';
import { ButtonGroup } from './components/ButtonGroup';
import { Card } from './components/Card';
import { Carousel } from './components/Carousel';
import { Chart } from './components/Chart';
import { Collapse } from './components/Collapse';
import { DataGrid } from './components/DataGrid';
import { DatePicker } from './components/DatePicker';
import { Dialog } from './components/Dialog';
import { Drawer } from './components/Drawer';
import { Dropdown } from './components/Dropdown';
import { Form } from './components/Form';
import { ImageGallery } from './components/ImageGallery';
import { Input } from './components/Input';
import { List } from './components/List';
import { Loader } from './components/Loader';
import { Masonry } from './components/Masonry';
import { Media } from './components/Media';
import { MegaMenu } from './components/MegaMenu';
import { Modal } from './components/Modal';
import { Navbar } from './components/Navbar';
import { Notification } from './components/Notification';
import { Offcanvas } from './components/Offcanvas';
import { Pagination } from './components/Pagination';
import { Panel } from './components/Panel';
import { Popover } from './components/Popover';
import { Progress } from './components/Progress';
import { Rating } from './components/Rating';
import { ScrollSpy } from './components/ScrollSpy';
import { Search } from './components/Search';
import { Sidebar } from './components/Sidebar';
import { Slider } from './components/Slider';
import { Spinner } from './components/Spinner';
import { Steps } from './components/Steps';
import { Switch } from './components/Switch';
import { Table } from './components/Table';
import { Tabs } from './components/Tabs';
import { Tag } from './components/Tag';
import { Timeline } from './components/Timeline';
import { Toast } from './components/Toast';
import { Tooltip } from './components/Tooltip';
import { TreeView } from './components/TreeView';
import { Wizard } from './components/Wizard';
import { DataTable } from './components/data/DataTable';
import { Filter } from './components/data/Filter';
import { DataPagination } from './components/data/Pagination';
import { Sort } from './components/data/Sort';
import { Autocomplete } from './components/form/Autocomplete';
import { Checkbox } from './components/form/Checkbox';
import { FormDatePicker } from './components/form/DatePicker';
import { FileUpload } from './components/form/FileUpload';
import { InputMask } from './components/form/InputMask';
import { Radio } from './components/form/Radio';
import { Range } from './components/form/Range';
import { Select } from './components/form/Select';
import { Validation } from './components/form/Validation';
import { Article } from './components/layout/Article';
import { Aside } from './components/layout/Aside';
import { Main } from './components/layout/Main';
import { Section } from './components/layout/Section';

// Core
import { Base } from './core/Base';
import { Component } from './core/Component';
import { Config } from './core/Config';
import { Constants } from './core/Constants';
import { EventEmitter } from './core/EventEmitter';
import { Instance } from './core/Instance';
import { Plugin } from './core/Plugin';

// Decorators
import { autobind } from './decorators/autobind';
import { deprecated } from './decorators/deprecated';
import { injectable } from './decorators/injectable';
import { throttle } from './decorators/throttle';

// Plugins
import { Analytics } from './plugins/Analytics';
import { Internationalization } from './plugins/Internationalization';
import { Router } from './plugins/Router';
import { StateManager } from './plugins/StateManager';
import { Theme } from './plugins/Theme';

// Services
import { ApiService } from './services/ApiService';
import { AuthService } from './services/AuthService';
import { CacheService } from './services/CacheService';
import { LoggerService } from './services/LoggerService';
import { StorageService } from './services/StorageService';

// Utilities
import { animate } from './utils/animation';
import { fetchData } from './utils/api';
import { arrayEquals, arrayToObject } from './utils/array';
import { isMobile, isTouchDevice, getBrowser } from './utils/browser';
import { hexToRgb, rgbToHex, lightenColor, darkenColor } from './utils/color';
import { formatDate } from './utils/date';
import {
  getElement,
  getElements,
  addClass,
  removeClass,
  toggleClass,
  hasClass,
  getFocusableElements,
  autoInitComponent,
} from './utils/dom';
import { on, off, once, trigger } from './utils/events';
import { formatNumber, formatCurrency, formatPercentage } from './utils/format';
import { addHook, removeHook, triggerHook } from './utils/hooks';
import { get, post } from './utils/http';
import { isEnterKey, isEscapeKey, isSpaceKey, isTabKey, isArrowUpKey, isArrowDownKey, isArrowLeftKey, isArrowRightKey } from './utils/keyboard';
import { clamp, random, round } from './utils/math';
import { deepClone, isObject, mergeDeep } from './utils/object';
import { getRoute, navigateTo } from './utils/router';
import { setLocalStorageItem, getLocalStorageItem, removeLocalStorageItem, setSessionStorageItem, getSessionStorageItem, removeSessionStorageItem } from './utils/storage';
import { capitalize, camelCaseToDash, dashToCamelCase, generateUUID } from './utils/string';
import { getStyle, setStyle, addStyles } from './utils/style';
import { delay, timestamp } from './utils/time';
import { isEmail, isRequired, isNumber, isInteger, isMinLength, isMaxLength, isBetween } from './utils/validation';

export {
  // Components
  Accordion,
  Alert,
  Avatar,
  Badge,
  Breadcrumb,
  Button,
  ButtonGroup,
  Card,
  Carousel,
  Chart,
  Collapse,
  DataGrid,
  DatePicker,
  Dialog,
  Drawer,
  Dropdown,
  Form,
  ImageGallery,
  Input,
  List,
  Loader,
  Masonry,
  Media,
  MegaMenu,
  Modal,
  Navbar,
  Notification,
  Offcanvas,
  Pagination,
  Panel,
  Popover,
  Progress,
  Rating,
  ScrollSpy,
  Search,
  Sidebar,
  Slider,
  Spinner,
  Steps,
  Switch,
  Table,
  Tabs,
  Tag,
  Timeline,
  Toast,
  Tooltip,
  TreeView,
  Wizard,
  DataTable,
  Filter,
  DataPagination,
  Sort,
  Autocomplete,
  Checkbox,
  FormDatePicker,
  FileUpload,
  InputMask,
  Radio,
  Range,
  Select,
  Validation,
  Article,
  Aside,
  Main,
  Section,

  // Core
  Base,
  Component,
  Config,
  Constants,
  EventEmitter,
  Instance,
  Plugin,

  // Decorators
  autobind,
  deprecated,
  injectable,
  throttle,

  // Plugins
  Analytics,
  Internationalization,
  Router,
  StateManager,
  Theme,

  // Services
  ApiService,
  AuthService,
  CacheService,
  LoggerService,
  StorageService,

  // Utilities
  animate,
  fetchData,
  arrayEquals,
  arrayToObject,
  isMobile,
  isTouchDevice,
  getBrowser,
  hexToRgb,
  rgbToHex,
  lightenColor,
  darkenColor,
  formatDate,
  getElement,
  getElements,
  addClass,
  removeClass,
  toggleClass,
  hasClass,
  getFocusableElements,
  autoInitComponent,
  on,
  off,
  once,
  trigger,
  formatNumber,
  formatCurrency,
  formatPercentage,
  addHook,
  removeHook,
  triggerHook,
  get,
  post,
  isEnterKey,
  isEscapeKey,
  isSpaceKey,
  isTabKey,
  isArrowUpKey,
  isArrowDownKey,
  isArrowLeftKey,
  isArrowRightKey,
  clamp,
  random,
  round,
  deepClone,
  isObject,
  mergeDeep,
  getRoute,
  navigateTo,
  setLocalStorageItem,
  getLocalStorageItem,
  removeLocalStorageItem,
  setSessionStorageItem,
  getSessionStorageItem,
  removeSessionStorageItem,
  capitalize,
  camelCaseToDash,
  dashToCamelCase,
  generateUUID,
  getStyle,
  setStyle,
  addStyles,
  delay,
  timestamp,
  isEmail,
  isRequired,
  isNumber,
  isInteger,
  isMinLength,
  isMaxLength,
  isBetween,
};

// Initialize components on DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
  Accordion.init();
  Alert.init();
  Avatar.init();
  Badge.init();
  Breadcrumb.init();
  Button.init();
  ButtonGroup.init();
  Card.init();
  Carousel.init();
  // Chart.init();
  Collapse.init();
  // DataGrid.init();
  // DatePicker.init();
  Dialog.init();
  Drawer.init();
  Dropdown.init();
  Form.init();
  // ImageGallery.init();
  Input.init();
  List.init();
  Loader.init();
  // Masonry.init();
  Media.init();
  MegaMenu.init();
  Modal.init();
  Navbar.init();
  Notification.init();
  Offcanvas.init();
  Pagination.init();
  Panel.init();
  Popover.init();
  Progress.init();
  Rating.init();
  // ScrollSpy.init();
  Search.init();
  Sidebar.init();
  Slider.init();
  Spinner.init();
  Steps.init();
  Switch.init();
  Table.init();
  Tabs.init();
  Tag.init();
  Timeline.init();
  Toast.init();
  Tooltip.init();
  TreeView.init();
  Wizard.init();
  // DataTable.init();
  // Filter.init();
  // DataPagination.init();
  // Sort.init();
  // Autocomplete.init();
  Checkbox.init();
  // FormDatePicker.init();
  // FileUpload.init();
  // InputMask.init();
  Radio.init();
  Range.init();
  Select.init();
  // Validation.init();
  Article.init();
  Aside.init();
  Main.init();
  Section.init();
});