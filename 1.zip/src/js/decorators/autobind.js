/* JS decorators files */ 
export function autobind(target, name, descriptor) {
    const originalMethod = descriptor.value;
    const adjustedDescriptor = {
      configurable: true,
      get() {
        const boundFn = originalMethod.bind(this);
        return boundFn;
      },
    };
    return adjustedDescriptor;
  }