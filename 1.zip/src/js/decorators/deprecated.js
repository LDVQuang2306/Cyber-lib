/* JS decorators files */ 
export function deprecated(message) {
    return function(target, name, descriptor) {
      const originalMethod = descriptor.value;
      descriptor.value = function(...args) {
        console.warn(`DEPRECATED: ${message}`);
        return originalMethod.apply(this, args);
      };
      return descriptor;
    };
  }