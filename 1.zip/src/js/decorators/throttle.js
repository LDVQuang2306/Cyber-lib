/* JS decorators files */ 
export function throttle(delay = 300) {
    return function(target, name, descriptor) {
      const originalMethod = descriptor.value;
      let timeout = null;
  
      descriptor.value = function(...args) {
        if (!timeout) {
          timeout = setTimeout(() => {
            originalMethod.apply(this, args);
            timeout = null;
          }, delay);
        }
      };
  
      return descriptor;
    };
  }