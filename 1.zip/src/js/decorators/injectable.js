/* JS decorators files */ 
export function injectable(target) {
    target.prototype.inject = function(dependency) {
      this[dependency.name] = new dependency();
    };
    return target;
  }