// Placeholder for TypeScript definitions for components
// You will need to define the types for each component and their options here

import { Accordion } from "../components/Accordion";
import { Alert } from "../components/Alert";
import { Avatar } from "../components/Avatar";
import { Badge } from "../components/Badge";
import { Breadcrumb } from "../components/Breadcrumb";
import { Button } from "../components/Button";
import { ButtonGroup } from "../components/ButtonGroup";
import { Card } from "../components/Card";
import { Carousel } from "../components/Carousel";
import { Dropdown } from "../components/Dropdown";
import { Modal } from "../components/Modal";
import { Navbar } from "../components/Navbar";
import { Tooltip } from "../components/Tooltip";
import { Toast } from "../components/Toast";

export interface ComponentOptions {
  [key: string]: any;
}

export interface ComponentConstructor {
  new (element: HTMLElement, options?: ComponentOptions): ComponentInstance;
  componentName: string;
  defaultOptions?: ComponentOptions;
}

export interface ComponentInstance {
  element: HTMLElement;
  options: ComponentOptions;
}

declare const Accordion: ComponentConstructor;
declare const Alert: ComponentConstructor;
declare const Avatar: ComponentConstructor;
declare const Badge: ComponentConstructor;
declare const Breadcrumb: ComponentConstructor;
declare const Button: ComponentConstructor;
declare const ButtonGroup: ComponentConstructor;
declare const Card: ComponentConstructor;
declare const Carousel: ComponentConstructor;
declare const Dropdown: ComponentConstructor;
declare const Modal: ComponentConstructor;
declare const Navbar: ComponentConstructor;
declare const Tooltip: ComponentConstructor;
declare const Toast: ComponentConstructor;

export {
  Accordion,
  Alert,
  Avatar,
  Badge,
  Breadcrumb,
  Button,
  ButtonGroup,
  Card,
  Carousel,
  Dropdown,
  Modal,
  Navbar,
  Tooltip,
  Toast,
};