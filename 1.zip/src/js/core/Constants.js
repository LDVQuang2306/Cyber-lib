/* JS core files */ 
export const Constants = {
    VERSION: '1.0.0', // Replace with your library's version number
    DATA_ATTRIBUTE: 'data-cp',
  };