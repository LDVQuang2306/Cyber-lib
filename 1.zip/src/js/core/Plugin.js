/* JS core files */ 
export class Plugin {
    constructor() {
      if (new.target === Plugin) {
        throw new TypeError('Cannot construct Plugin instances directly');
      }
    }
  
    static get pluginName() {
      throw new Error('Plugin name must be defined.');
    }
  }