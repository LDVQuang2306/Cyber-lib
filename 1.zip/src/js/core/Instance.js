/* JS core files */ 
const _instances = new WeakMap();

export class Instance {
  constructor(element) {
    if (_instances.has(element)) {
      return _instances.get(element);
    }

    _instances.set(element, this);
    this.element = element;
  }

  static get instances() {
    return _instances;
  }
}