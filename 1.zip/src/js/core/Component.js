/* JS core files */ 
import { Config } from './Config';
import { autoInitComponent } from '../utils/dom';

export class Component extends Config {
  constructor(element, options = {}) {
    super(options);

    this.element = element;
  }

  static init(options = {}) {
    autoInitComponent(this.componentName, options, this);
  }
}