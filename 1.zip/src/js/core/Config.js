/* JS core files */ 
import { mergeDeep } from '../utils/object';

export class Config {
  constructor(options) {
    this.options = mergeDeep(this.constructor.defaultOptions, options);
  }

  static get defaultOptions() {
    return {};
  }

  static get componentName() {
    throw new Error('Component name must be defined.');
  }
}